window.ASV_CONFIG={
  chainIdHex:"0x38",
  rpc:"https://bsc-dataseed.binance.org",
  token:{address:"0x2682FA44105a60F2016FAa8909eA82d3d427bfFc",symbol:"ASV-A",decimals:18},
  receiver:"0x8a898a58d96013c33477b0a7606a83fd5bec7abc",
  vitalityScale:1000
};